import React from "react";
import Time from "./time";
import AdminFooter from "./components/AdminFooter"
import Final from "./components/final"
import "./components/All.css";
import 'font-awesome/css/font-awesome.min.css';
import Home from "./components/Home"
import Coming from "./components/Comings00n";
export default function App(){
  return (
   
   <>
    <Final/>
 
   </>
  )
}