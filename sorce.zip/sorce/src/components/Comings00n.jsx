import "./All.css"
function Coming(){
    return(
        <>
        <div className="Comming-image">
            <img src="/istockphoto-1279537022-1024x1024.jpg" alt="" />
        </div>
        </>
    )
}

export default Coming;